import Logo from "./images/Logo.png";
import Perfil from "./images/Perfil.jpg"
import Contenido from "./images/Contenido.jpg";
import Separacion from "./images/Separacion.png";

export default {

    "img1": Logo,
    "img2": Perfil,
    "img3": Contenido,
    "img4": Separacion
}